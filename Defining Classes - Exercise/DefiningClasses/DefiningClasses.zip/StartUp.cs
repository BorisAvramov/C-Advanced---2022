﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person person = new Person();
            Console.WriteLine(person.Name);
            Console.WriteLine(person.Age);

            Person otherPerson = new Person("Pesho", 30);

            Console.WriteLine(otherPerson.Name);
            Console.WriteLine(otherPerson.Age);

        }
    }
}
