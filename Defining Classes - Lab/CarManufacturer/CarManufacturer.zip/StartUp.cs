﻿using System;

namespace CarManufacturer
{
    public class StartUp
    {   
        public static void Main(string[] args)
        {
            Car myCar = new Car();

            myCar.Make = "VW";

            myCar.Model = "MK3";

            myCar.Year = 1992;



            myCar.FuelQuantity = 200;
            myCar.FuelConsumtion = 200;
            myCar.Drive(2000);

            Console.WriteLine(myCar.WhoAmI());


            string make = Console.ReadLine();
            string model = Console.ReadLine();
            int year = int.Parse(Console.ReadLine());
            double fuelQuantity = double.Parse(Console.ReadLine());
            double fuelConsumtion = double.Parse(Console.ReadLine());

            Car Car = new Car();

            Car herCar = new Car(make, model, year);

            Car hisCar = new Car(make,model,year,fuelQuantity,fuelConsumtion);

            //Console.WriteLine($"{Car.Make}, {Car.Model}, {Car.Year}, {Car.FuelQuantity}, {Car.FuelConsumtion}");

            //Console.WriteLine($"{herCar.Make}, {herCar.Model}, {herCar.Year}, {herCar.FuelQuantity}, {herCar.FuelConsumtion}");

            //Console.WriteLine($"{hisCar.Make}, {hisCar.Model}, {hisCar.Year}, {hisCar.FuelQuantity}, {hisCar.FuelConsumtion}");

            Tire[] tires = new Tire[]
                {
                    new Tire(1, 2.5),
                    new Tire(1, 2.5),
                    new Tire(2, 3.5),
                    new Tire(2, 3.5)
                };

            Engine engine = new Engine(125, 2000);

            Car newCar = new Car("VW", "Passat", 2003, 50, 10, engine, tires);

        }
    }
}
