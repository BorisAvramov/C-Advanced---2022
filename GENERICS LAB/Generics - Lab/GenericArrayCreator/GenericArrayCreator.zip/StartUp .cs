﻿using System;

namespace GenericArrayCreator
{
    public class StartUp
    {
        static void Main(string[] args)
        {

            int[] arr = ArrayCreator.Create<int>(5, 6);

            Console.WriteLine(String.Join(" ", arr));



        }
    }
}
