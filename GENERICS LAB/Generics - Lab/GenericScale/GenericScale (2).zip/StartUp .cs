﻿using System;

namespace GenericScale
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            //int left = 10;
            //int right = 20;

            //EqualityScale

        }
    }
}
