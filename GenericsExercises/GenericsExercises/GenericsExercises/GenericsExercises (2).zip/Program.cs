﻿using System;

namespace GenericsExercises
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int intValue = int.Parse(Console.ReadLine());
            Box<int> box = new Box<int>();

            for (int i = 0; i < intValue; i++)
            {
                
               box.Add(int.Parse(Console.ReadLine()));


            }

            Console.WriteLine( box.ToString()); 
        }
    }
}
