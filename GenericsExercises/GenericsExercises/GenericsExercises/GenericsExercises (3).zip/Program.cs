﻿using System;

namespace GenericsExercises
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int intValue = int.Parse(Console.ReadLine());
            Box<string> box = new Box<string>();

            for (int i = 0; i < intValue; i++)
            {
                
               box.Add(Console.ReadLine());


            }

            string[] stringElements = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            int index1 = int.Parse(stringElements[0]);
            int index2 = int.Parse(stringElements[1]);
            box.Swap(index1, index2);
            Console.WriteLine( box.ToString()); 
        }

        
    }
}
