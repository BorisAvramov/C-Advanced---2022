﻿using System;
using System.Linq;

namespace GenericsExercises
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int intValue = int.Parse(Console.ReadLine());
            Box<string> box = new Box<string>();

            for (int i = 0; i < intValue; i++)
            {

                box.Add(Console.ReadLine());


            }

            //int[] intElements = Console.ReadLine()
            //    .Split(" ", StringSplitOptions.RemoveEmptyEntries)
            //    .Select(int.Parse)
            //    .ToArray();
            //int index1 = intElements[0];
            //int index2 = intElements[1];
            //box.Swap(index1, index2);

            string elementToCompare = Console.ReadLine();
            Console.WriteLine(box.Compare(elementToCompare));

            //Console.WriteLine( box.ToString()); 
        }

        
    }
}
