﻿using System;

namespace GenericsExercises
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int intValue = int.Parse(Console.ReadLine());
            Box<string> box = new Box<string>();

            for (int i = 0; i < intValue; i++)
            {
                
               box.Add(Console.ReadLine());


            }

            Console.WriteLine( box.ToString()); 
        }
    }
}
