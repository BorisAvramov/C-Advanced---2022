﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ListyIterator
{
    public class ListyIterator <T>
    {
        private readonly List<T> list;
        private int internalIndex;
        public ListyIterator(List<T> list)
        {
            this.list = list;
            internalIndex = 0;
        }

        public bool Move()
        {
            if (HasNext())
            {
                internalIndex++;
                return true;
            }
            return false;
        }

        public bool HasNext() 
        {

            return internalIndex + 1 < list.Count;
        }
        public void Print()
        {
            if (list.Any())
            {
                Console.WriteLine(list[internalIndex]);
            }
            else
            {
                throw new InvalidOperationException("Invalid Operation!");
            }
            


        }
    }
}
